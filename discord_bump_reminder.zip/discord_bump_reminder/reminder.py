#!/usr/bin/env python3
"""Reminder-only Discord post tracker. It never logs into Discord or posts replies."""
import json
import os
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
STATE_PATH = BASE_DIR / "state.json"
def load_dotenv():
    env_path = BASE_DIR / ".env"
    if not env_path.exists():
        return
    for raw in env_path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

load_dotenv()
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "30"))

def load_json(path, default):
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def save_json(path, data):
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    tmp.replace(path)

def send_ntfy(title, message, click_url):
    topic = os.getenv("NTFY_TOPIC", "").strip()
    if not topic:
        print("NTFY_TOPIC not set; skipping push notification.")
        return False
    req = urllib.request.Request(
        f"https://ntfy.sh/{topic}",
        data=message.encode("utf-8"),
        headers={"Title": title, "Priority": "default", "Click": click_url, "Tags": "bell"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            return 200 <= response.status < 300
    except Exception as exc:
        print(f"ntfy error: {exc}")
        return False

def send_discord_webhook(title, message, click_url):
    webhook = os.getenv("DISCORD_WEBHOOK_URL", "").strip()
    if not webhook:
        print("DISCORD_WEBHOOK_URL not set; skipping Discord-channel notification.")
        return False
    payload = {"embeds": [{
        "title": title[:256], "description": message[:4000],
        "url": click_url, "color": 5763719
    }]}
    req = urllib.request.Request(
        webhook,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            return 200 <= response.status < 300
    except Exception as exc:
        print(f"Discord webhook error: {exc}")
        return False

def main():
    config = load_json(CONFIG_PATH, {"posts": []})
    state = load_json(STATE_PATH, {})
    posts = config.get("posts", [])
    if not posts:
        print("No posts configured. Add entries to config.json and restart.")
        return

    print(f"Watching {len(posts)} post(s); checking every {POLL_SECONDS}s.")
    while True:
        now = int(time.time())
        changed = False
        for post in posts:
            post_id = str(post["id"])
            url = post["message_url"]
            channel = post.get("channel", "Discord channel")
            interval = int(post["interval_minutes"])
            if interval < 5:
                print(f"Skipping {post_id}: minimum interval is 5 minutes.")
                continue

            if post_id not in state:
                state[post_id] = {"next_due": now + interval * 60}
                changed = True
                continue

            if now >= int(state[post_id]["next_due"]):
                title = f"Time to check your post: {channel}"
                message = (
                    "Your post is due for a manual check/bump.\n"
                    f"Channel: {channel}\n"
                    "Open the original post and follow that server's posting rules."
                )
                push_ok = send_ntfy(title, message, url)
                discord_ok = send_discord_webhook(title, message, url)
                print(
                    f"[{datetime.now(timezone.utc).isoformat()}] Due: {post_id}; "
                    f"ntfy={push_ok}; discord_webhook={discord_ok}"
                )
                state[post_id]["next_due"] = now + interval * 60
                changed = True

        if changed:
            save_json(STATE_PATH, state)
        time.sleep(POLL_SECONDS)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
