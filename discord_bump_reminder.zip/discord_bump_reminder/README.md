# Discord Post Bump Reminder

A small, 24/7 reminder service for multiple Discord message links and custom intervals.
It does **not** log into Discord, monitor external servers, or post replies. You open
the original post and manually bump only where the server's rules permit it.

## Notifications included

- **Push notification:** ntfy can notify your phone and desktop/browser.
- **Discord notification:** an optional Discord webhook posts an alert to a channel
  where you have permission to create a webhook (for example, a private channel in
  your own server). A webhook does not DM your account and cannot post into servers
  where you do not have permission.

## 1. Prepare the configuration

Edit `config.json`. Each post needs:
- a unique `id`
- a readable `channel` label
- the Discord message link (`Copy Message Link`)
- `interval_minutes`, set to the interval allowed by that server

The sample contains two example rows. Replace the placeholder URLs. Add more objects
for more servers. Keep intervals at or above each server's permitted bump frequency.
The app enforces a 5-minute technical minimum, but server rules may require much longer.

## 2. Set up push notifications with ntfy

1. Install the **ntfy** app on your phone, or open https://ntfy.sh/ in your desktop browser.
2. Choose a long, hard-to-guess topic name, for example a random string. Do not post it
   publicly: anyone who knows a public ntfy topic name may be able to subscribe.
3. Subscribe to that same topic in the app/browser.
4. Copy `.env.example` to `.env` and set `NTFY_TOPIC` to your private topic name.

For stronger privacy, use an authenticated/self-hosted ntfy server rather than a public
topic. The example uses the public ntfy service for simplicity.

## 3. Optional Discord notifications

If you want an alert inside Discord as well:
1. In a Discord server/channel that you own or administer, open channel settings.
2. Find **Integrations → Webhooks → New Webhook** (wording may vary).
3. Copy the webhook URL and put it in `.env` as `DISCORD_WEBHOOK_URL`.
4. Keep that URL secret. Anyone with it can post to that webhook.

This sends reminders to your chosen private channel. It does not send a Discord DM.

## 4. Run on an Ubuntu VPS (24/7)

You need an Ubuntu VPS from a cloud host. Connect using SSH.

Install Python:
```bash
sudo apt update
sudo apt install -y python3
```

Upload/extract this folder on the VPS, then:
```bash
sudo mkdir -p /opt/discord-bump-reminder
sudo cp reminder.py config.json .env.example /opt/discord-bump-reminder/
sudo chown -R "$USER":"$USER" /opt/discord-bump-reminder
cd /opt/discord-bump-reminder
cp .env.example .env
nano config.json
nano .env
```

Edit `config.json` and `.env`, save, then test:
```bash
python3 reminder.py
```
Stop the test with `Ctrl+C`.

## 5. Keep it running after logout/reboot

Create a service file:
```bash
sudo nano /etc/systemd/system/discord-bump-reminder.service
```

Paste this, replacing `YOUR_LINUX_USERNAME` with the output of `whoami`:
```ini
[Unit]
Description=Discord Post Bump Reminder
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/discord-bump-reminder
EnvironmentFile=/opt/discord-bump-reminder/.env
ExecStart=/usr/bin/python3 /opt/discord-bump-reminder/reminder.py
Restart=always
RestartSec=10
User=YOUR_LINUX_USERNAME

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now discord-bump-reminder
sudo systemctl status discord-bump-reminder
```

View logs:
```bash
journalctl -u discord-bump-reminder -f
```

Restart after editing the config:
```bash
sudo systemctl restart discord-bump-reminder
```

## Important behavior

- First reminder for each post is sent after its configured interval from first startup.
- After each reminder, the next reminder is scheduled using that post's interval.
- The service stores reminder timing in `state.json`.
- If the VPS is offline at a due time, it sends the reminder on the next check after it comes back.
- The script does not confirm whether a message still exists or whether bumping is allowed.
- Respect server rules and avoid repetitive unsolicited messages.
